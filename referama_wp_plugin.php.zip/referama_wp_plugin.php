<?php
/*
Plugin Name: Referama Wordpress Plugin
Plugin URI: http://www.referama.com
Description: Integrates Referama into your Wordpress
Version: 0.1
Author: Referama
Author URI: http://www.referama.com
License: GPL2
*/

add_shortcode('referama', 'referama_embed');

function referama_embed($args){
    extract( shortcode_atts( array(
      'collection_id' => 0,
      'visualization' => 'people1')
      ), $args ) ;

    if ($collection_id != 0){
      return "<h1>klahdkjsa</h1>";
    }
}


?>
